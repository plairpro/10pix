CREATE TABLE `pixel_actions` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`user` text NOT NULL,
	`cell` integer NOT NULL,
	`color` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `actions_user_idx` ON `pixel_actions` (`user`);--> statement-breakpoint
CREATE INDEX `actions_cell_idx` ON `pixel_actions` (`cell`);