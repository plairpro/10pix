import { sqliteTable, integer, text, index } from 'drizzle-orm/sqlite-core';
export const strokes = sqliteTable('strokes', {
 id: integer('id').primaryKey({autoIncrement:true}),
 user: text('user').notNull().unique(),
 cell: integer('cell').notNull(),
 color: text('color').notNull(),
}, t => [index('cell_idx').on(t.cell)]);
export const pixelActions = sqliteTable('pixel_actions', {
 id: integer('id').primaryKey({autoIncrement:true}),
 user: text('user').notNull(),
 cell: integer('cell').notNull(),
 color: text('color').notNull(),
}, t => [index('actions_user_idx').on(t.user),index('actions_cell_idx').on(t.cell)]);
