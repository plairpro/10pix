import { env } from 'cloudflare:workers';
export const dynamic='force-dynamic';
function browserId(r:Request){return r.headers.get('cookie')?.match(/(?:^|;\s*)pixel_browser=([a-f0-9-]{36})(?:;|$)/)?.[1]??null}
const reply=(data:unknown,status=200,cookie?:string)=>Response.json(data,{status,headers:{'Cache-Control':'no-store',...(cookie?{'Set-Cookie':cookie}:{})}});
export async function GET(request:Request){
 const db=env.DB!,id=browserId(request)??crypto.randomUUID(),user='browser:'+id;
 const cookie=`pixel_browser=${id}; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000${new URL(request.url).protocol==='https:'?'; Secure':''}`;
 const rows=await db.prepare(`SELECT cell,color FROM (SELECT cell,color,ROW_NUMBER() OVER(PARTITION BY cell ORDER BY generation DESC,id DESC) rank FROM (SELECT id,cell,color,0 generation FROM strokes UNION ALL SELECT id,cell,color,1 generation FROM pixel_actions)) WHERE rank=1`).all();
 const mine=await db.prepare(`SELECT id,source FROM (SELECT id,0 source FROM strokes WHERE user=? UNION ALL SELECT id,1 source FROM pixel_actions WHERE user=?) ORDER BY source DESC,id DESC`).bind(user,user).all();
 return reply({pixels:rows.results,filled:rows.results.length,remaining:Math.max(0,10-mine.results.length),last:mine.results[0]??null},200,cookie);
}
export async function POST(request:Request){
 if(request.headers.get('origin')!==new URL(request.url).origin)return reply({error:'Недопустимый запрос'},403);
 const id=browserId(request);if(!id)return reply({error:'Разрешите cookie и обновите страницу.'},400);
 const user='browser:'+id;let body;try{body=await request.json() as {action?:string,id:number,source:number,cell:number,color:string}}catch{return reply({error:'Некорректный запрос'},400)}
 if(!body)return reply({error:'Некорректный запрос'},400);
 if(body.action==='undo'){
  if(!Number.isInteger(body.id)||![0,1].includes(body.source))return reply({error:'Некорректная отмена'},400);
  const query=body.source===1?`DELETE FROM pixel_actions WHERE id=? AND user=? AND id=(SELECT MAX(id) FROM pixel_actions WHERE user=?)`:`DELETE FROM strokes WHERE id=? AND user=? AND NOT EXISTS(SELECT 1 FROM pixel_actions WHERE user=?)`;
  const r=await env.DB!.prepare(query).bind(body.id,user,user).run();
  return r.meta.changes?reply({ok:true}):reply({error:'Действие уже отменено. Обновите полотно.'},409);
 }
 if(!Number.isInteger(body.cell)||body.cell<0||body.cell>=20736||typeof body.color!=='string'||!/^#[0-9a-fA-F]{6}$/.test(body.color))return reply({error:'Выберите клетку и цвет'},400);
 const r=await env.DB!.prepare(`INSERT INTO pixel_actions(user,cell,color) SELECT ?,?,? WHERE (SELECT COUNT(*) FROM pixel_actions WHERE user=?)+(SELECT COUNT(*) FROM strokes WHERE user=?) < 10`).bind(user,body.cell,body.color.toLowerCase(),user,user).run();
 return r.meta.changes?reply({ok:true}):reply({error:'Все 10 пикселей использованы'},409);
}
