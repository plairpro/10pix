'use client';
import {useEffect,useRef,useState} from 'react';
const colors=['#171717','#6b7280','#ffffff','#ed4545','#ff8243','#f7ca45','#9acb62','#308d69','#3abfc1','#4487df','#6b5bd2','#b579da','#ee87b4','#8b6149'];
type Board={pixels:{cell:number,color:string}[],filled:number,remaining:number,last:null|{id:number,source:number}};
export default function Home(){
 const canvas=useRef<HTMLCanvasElement>(null),busy=useRef(false);
 const [board,setBoard]=useState<Board>({pixels:[],filled:0,remaining:10,last:null}),[ready,setReady]=useState(false),[color,setColor]=useState('#ff8243'),[error,setError]=useState(''),[saving,setSaving]=useState(false);
 function apply(data:Board){setBoard(data);setReady(true);const ctx=canvas.current?.getContext('2d');if(!ctx)return;ctx.fillStyle='#fff';ctx.fillRect(0,0,1920,1080);for(const p of data.pixels){ctx.fillStyle=p.color;ctx.fillRect(p.cell%192*10,Math.floor(p.cell/192)*10,10,10)}}
 async function read(){const r=await fetch('/api/canvas');if(!r.ok)throw Error('Не удалось обновить полотно');apply(await r.json() as Board)}
 async function sync(){if(busy.current)return;busy.current=true;try{await read();setError('')}catch(e){setError((e as Error).message)}finally{busy.current=false}}
 useEffect(()=>{sync();const id=setInterval(()=>{if(!document.hidden)sync()},10000);return()=>clearInterval(id)},[]);
 async function change(data:object){if(busy.current)return;busy.current=true;setSaving(true);setError('');try{const r=await fetch('/api/canvas',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const result=await r.json() as {error?:string};await read();if(!r.ok)throw Error(result.error||'Не удалось сохранить')}catch(e){setError((e as Error).message)}finally{busy.current=false;setSaving(false)}}
 return <main><div className="counter">Закрашено пикселей: <b>{ready?board.filled.toLocaleString('ru'):'—'}</b></div>
 <div className="layout"><aside><p>Ваши пиксели —<br/>часть общей картины</p><img src="/qr.svg" width="140" height="140" alt="QR-код полотна"/></aside>
 <section className="drawing"><div className="frame"><canvas ref={canvas} width={1920} height={1080} aria-label="Закрасить пиксель" onClick={e=>{if(!ready||saving||!board.remaining)return;const r=e.currentTarget.getBoundingClientRect();const cell=Math.max(0,Math.min(107,Math.floor((e.clientY-r.top)/r.height*108)))*192+Math.max(0,Math.min(191,Math.floor((e.clientX-r.left)/r.width*192)));change({cell,color})}}/></div>
 <div className="toolbar"><div className="palette">{colors.map(c=><button key={c} title={c} aria-label={'Цвет '+c} aria-pressed={color===c} className={color===c?'active':''} style={{background:c}} onClick={()=>setColor(c)}/>)}<label className="custom" title="Другой цвет"><input aria-label="Свой цвет" type="color" value={color} onChange={e=>setColor(e.target.value)}/></label></div>
 <div className="tools"><span aria-label="Осталось пикселей">{ready?board.remaining:'—'}/10</span><button title="Отменить последний пиксель" aria-label="Отменить последний пиксель" disabled={!ready||saving||!board.last} onClick={()=>board.last&&change({action:'undo',...board.last})}><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M9 5 3 10l6 5M3 10h11a6 6 0 0 1 0 12" transform="translate(0 -2)"/></svg></button></div></div>
 {error&&<p className="error" role="alert">{error}</p>}</section></div></main>
}
